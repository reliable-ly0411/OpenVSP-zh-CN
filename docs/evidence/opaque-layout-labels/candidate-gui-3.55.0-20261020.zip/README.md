# OpenVSP 3.55.0 native candidate: opaque-name GUI regression

Actual assistant-cloud Linux AMD64/X11 checks on 2026-10-20, approximately 10:09–10:14 UTC. This is a new local candidate, not a rebuilt or replacement rc.2 asset.

## Observed result

All three demonstrated display-only defects pass the targeted GUI check: Parasite Drag component `(+) Fuselage`, excrescence summary `Wing`, and UserParm Adjust group divider `Wing` retain the synthetic user text. The parameter `Export` and editor values remain raw. Fixed labels/dividers remain Chinese. Six original PNG captures are included and identified in `manifest.json`.

The same synthetic model used to reproduce the original 3.55 package defects was opened, inspected, then saved through the GUI exit dialog. The app returned normally. XML readback confirms the targeted names, descriptions, attributes and IDs are unchanged. The only serialized difference from input is the view Zoom floating-point normalization, shown in `model-save.diff`; this is not byte-identical file retention.

## Candidate identity

- Tested local source: `5379906d4c113684a17275aaed0872f91dc0a5ac`
- Equivalent public source: `546b71549eaf443c4e746d61d0ac0eff29f0828e`
- Whole source tree: `4afdc4ecf9c5bf88a98a27920eff11fc4318c487` (8,643 blobs verified)
- Native binary SHA256: `29daadcfe3cf1689ffd415202afe344b664ec52d257a101f8016ebcabe3b8290`
- Draft review: https://github.com/reliable-ly0411/OpenVSP-zh-CN/pull/76

`build-receipt-before-gui.json` is the original builder receipt at 10:08:34 UTC. Its `gui_launched: false` describes that earlier build checkpoint; the later actual GUI outcome is recorded separately in `manifest.json`. The original receipt is deliberately not rewritten. Chinese `vsp -help` and resolved runtime-library evidence are included.

## Limits

This was an isolated vsp-only native build, not a release package. VSPAERO programs, help and Python/API wrappers were not built. Missing solver/viewer/loads/help warnings are expected and retained; the synthetic HumanGeom exclusion warning is unrelated to the repaired label paths. No full packaging or all-platform acceptance is claimed.

Only 3.55 Linux AMD64 candidate GUI was checked. The other four repaired families have their source/runtime regression evidence but no native candidate GUI pass from this run. Windows/macOS/ARM GUI remain unreviewed. FLTK mnemonic/symbol drawing semantics remain unchanged. No rc.2 tags, assets or releases were modified, no PR was merged, and no new release is authorized by this evidence.

All models are assistant-generated synthetic fixtures. The bundle contains only the relevant OpenVSP screenshots, fixture, readback, receipts and scoped logs; no personal model or credentials.
