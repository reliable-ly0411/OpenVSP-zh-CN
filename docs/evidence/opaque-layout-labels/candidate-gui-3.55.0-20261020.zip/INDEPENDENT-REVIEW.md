# Independent evidence review

Read-only review completed 2026-10-20 at approximately 10:17 UTC. The reviewer inspected the original six PNGs, the candidate binary identity, and the full original-to-saved XML diff. The reviewer did not independently witness launching, saving or closing the app; those actions were observed by the GUI operator.

Result: PASS for the three targeted opaque-name paths, with no target mismatch found.

- Screenshots 02 and 03 show the Parasite Drag component `(+) Fuselage`, not `(+) 机身`.
- Screenshot 03 shows `Wing` in the excrescence list, editable name field and summary, not `机翼`.
- Screenshot 04 shows the UserParm Adjust group divider `Wing` with parameter label `Export`.
- Screenshot 06 shows Name `Export`, Group `Wing`, Description `Cancel`, all raw.
- Fixed captions remain Chinese, including `寄生阻力`, `附加阻力项`, `用户参数`, `预定义`, `创建参数`, `用户自定义参数` and `编辑用户自定义参数`.
- Screenshots 01, 02 and 04 preserve the synthetic path `Wing Design/Export/Mass Properties.vsp3`; the visible application version is 3.55.0.
- The full XML diff changes exactly one line: AdjustView Zoom float serialization. No other serialized lines, including the tested names, changed.
- Candidate binary SHA256 matches the build receipt, and the binary is ELF x86-64 GNU/Linux.

The earlier builder receipt is retained without modification. Its `gui_launched: false` describes build-time state, not the later GUI session. These checks cover this local 3.55 Linux AMD64 candidate and the specified paths only. They do not establish all-platform, full-package or comprehensive GUI acceptance.
