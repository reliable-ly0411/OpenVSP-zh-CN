# Original-package dynamic-name reproduction evidence

These are actual, newly captured 2026-10-20 cloud-desktop PNGs and generated synthetic models, not a receipt-only archive. They reproduce three display bugs before the candidate fix.

- Parasite Drag component: `Fuselage` displays as `(+) 机身`.
- UserParm Adjust group: `Wing` displays as `机翼`.
- Parasite Drag excrescence summary: `Wing` displays as `机翼`.

Direct GUI reproduction covers original 3.55.0 and 3.51.2 Linux AMD64 packages. All five exact rc.2 source anchors have the corresponding translating helper calls, but other-family GUI reproduction is not claimed here. Windows/macOS/ARM GUI remain unreviewed. No repaired candidate is pictured.

The manifest preserves source anchors, original ZIP names/hashes, screenshot save times, file hashes and XML readback. The saved models preserve the raw geometry, parameter/group/description and excrescence names. Both models contain only synthetic fixtures made for testing.

For 3.51.2 the group header was refreshed by creating a second synthetic parameter; `10-userparm-group-after-layout-refresh.png` is the definitive group screenshot. The unrelated upstream layout-refresh behavior was not classified as a new localization bug. The ampersand appearance in a geometry button follows FLTK mnemonic rendering; the model XML still contains the original ampersand.

The full original packages, release tags, published assets and Latest selection remain unchanged. This evidence supports review of a separate repair, not retroactive rc.2 GUI acceptance.
